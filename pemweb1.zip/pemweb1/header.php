<div class="container">
    <div class="row gy-4">
        <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center" data-aos="zoom-out">
            <h1>Puskesmas <span>Sehat</span></h1>
            <p>Kesehatan Anda adalah Prioritas Kami</p>
        </div>
    </div>
</div>